
#include "hal_sys.h"
#include "api_hal_pm.h"

void HAL_Sys_reboot()
{
    PM_Reboot();
}

