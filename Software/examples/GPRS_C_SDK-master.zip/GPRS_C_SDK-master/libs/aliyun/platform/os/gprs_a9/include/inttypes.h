
#include "stdint.h"


#define PRIi32 "li"
