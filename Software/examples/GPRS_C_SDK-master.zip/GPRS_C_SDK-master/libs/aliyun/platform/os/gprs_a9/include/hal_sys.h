#ifndef __ALIYUN_HAL_SYS_H
#define __ALIYUN_HAL_SYS_H

void HAL_Sys_reboot();

#endif
