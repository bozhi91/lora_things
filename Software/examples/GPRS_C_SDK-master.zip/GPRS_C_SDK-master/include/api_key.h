#ifndef __API_KEY_H
#define __API_KEY_H


typedef enum{
    KEY_POWER = 0x4B,
    KEY_MAX
} Key_ID_t;

#endif

