#ifndef _API_INC_SIM_H
#define _API_INC_SIM_H


typedef enum{
    SIM0      = 0,
    SIM_ID_MAX
}SIM_ID_t;



#endif
