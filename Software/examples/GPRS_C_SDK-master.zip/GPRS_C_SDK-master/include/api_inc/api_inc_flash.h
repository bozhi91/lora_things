#ifndef __API_INC_FLASH_H
#define __API_INC_FLASH_H

typedef void (*HAL_FLASH_CALLBACK_FUNCTION_T)(void * param);

#endif

