#ifndef __API_INC_FOTA_H
#define __API_INC_FOTA_H

typedef void (*fota_handler_t)(const unsigned char *pData, int len);

#endif
