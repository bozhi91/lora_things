#ifndef __API_SYS_H__
#define __API_SYS_H__

#ifdef __cplusplus
extern "C"{
#endif

#include "sdk_init.h"


#define SYS_EnterCriticalSection     CSDK_FUNC(SYS_EnterCriticalSection)
#define SYS_ExitCriticalSection      CSDK_FUNC(SYS_ExitCriticalSection)



#ifdef __cplusplus
}
#endif

#endif

