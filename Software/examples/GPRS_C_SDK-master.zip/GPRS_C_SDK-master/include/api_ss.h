#ifndef __API_SS_H_
#define __API_SS_H_

#include <sdk_init.h>



// uint32_t SS_SendUSSD(USSD_Type_t );
#define SS_SendUSSD    CSDK_FUNC(SS_SendUSSD)

#endif
