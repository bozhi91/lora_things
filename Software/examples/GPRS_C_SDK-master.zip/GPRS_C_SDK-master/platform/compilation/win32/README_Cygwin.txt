##################################################
# Cygwin setup for Granite
################################################

Please contact your prefered Coolsand FAE or AE to get
the software environement documentation or visit the
internal wiki:

http://atlas/twiki/bin/view/CoolWiki/SoftwareDevelopmentEnvironment



