
<!--


# Please read and awnser the questrion below if you want to resolve your problem soon
# 如果希望问题(早点)得到解决，请认真阅读并填写以下问题


为保证问题得到解决，请在提问前请在issue查找或搜索是否已经存在相同问题
issue地址：https://github.com/Ai-Thinker-Open/GPRS_C_SDK/issues?utf8=%E2%9C%93&q=

-->


## 1. SDK version（SDK 版本）

{





}

---


## 2. In what kind of operation problems appear, and how to reproduce the problem ?（什么样的操作步骤问题会出现，是否是稳定复现，如何复现问题？）

{





}

---
