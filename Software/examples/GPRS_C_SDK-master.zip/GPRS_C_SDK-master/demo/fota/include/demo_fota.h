#ifndef __FOTA_H
#define __FOTA_H


#endif

void FOTA_UartTest(void);
void FOTASERVER_Test(void);

