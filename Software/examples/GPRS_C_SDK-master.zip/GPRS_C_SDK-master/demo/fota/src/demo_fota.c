

#include "api_os.h"
#include "demo_fota.h"

void fota_Main(void)
{
    FOTA_UartTest();
    // FOTASERVER_Test();
}

