
SSD1306 spi oled display demo
====

|Oled Pin| SPI   | A9 |
|--------|-------| -- |
| GND    | GND   | GND|
| VCC    | 3~5.5V|VBAT/VUSB/VIO|
| D0     | SPI CLK| IO0|
| D1     | SPI MO | IO3|
| RES    |  NC   | IO6|
| DC     |  NC   | IO7|
| CS     | SPI CS| IO1|


![](./assets/ssd1306_oled.gif)

