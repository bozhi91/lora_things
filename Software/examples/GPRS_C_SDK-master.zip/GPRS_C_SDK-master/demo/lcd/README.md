
lcd spi display demo
====

e.g. ili9341

|LCD Pin |A9          |
|--------|--          |
| GND    |GND         |
| VCC    |            |
| MOSI   |LCD_DIO/IO17|
| MISO   |            |
| SCK    |LCD_SCK/IO16|
| RES    |LCD_RST/IO14|
| DC     |LCD_SDC/IO18|
| CS     |LCD_CD/IO15 |




