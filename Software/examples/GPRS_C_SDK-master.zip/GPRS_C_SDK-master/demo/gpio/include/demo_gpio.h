#ifndef __BLINK_H_
#define __BLINK_H_


#define GPIO_PIN_LED_BLUE   GPIO_PIN27
#define GPIO_PIN_LED_GREEN  GPIO_PIN28   


#endif

