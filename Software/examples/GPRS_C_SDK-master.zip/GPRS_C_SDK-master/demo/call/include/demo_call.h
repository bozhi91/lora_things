#ifndef __DEMO_CALL_H_
#define __DEMO_CALL_H_

#define DIAL_NUMBER "150....0062"

#endif

