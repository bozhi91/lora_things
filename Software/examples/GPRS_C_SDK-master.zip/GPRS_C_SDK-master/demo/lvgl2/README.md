
 [LVGL(LittlevGL)](https://littlevgl.com/) display on ili9341 320x240 LCD 
====

LCD ili9341

|LCD Pin |A9          |
|--------|--          |
| GND    |GND         |
| VCC    |            |
| MOSI   |LCD_DIO/IO17|
| MISO   |            |
| SCK    |LCD_SCK/IO16|
| RES    |LCD_RST/IO14|
| DC     |LCD_SDC/IO18|
| CS     |LCD_CD/IO15 |


LVGL examples [here](https://github.com/littlevgl/lv_examples/tree/master/lv_tutorial)

