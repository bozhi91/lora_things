#ifndef _MQTT_EXAMPLE_H
#define _MQTT_EXAMPLE_H


int aliyun_mqtt_main(int argc, char **argv);

#endif

